# Example Hello World

1. [task][SimpleHelloWorld greetings()](TestHelloWorld | Tests if the greetings method returns the correct string.)
    Implementieren Sie die Methode `greetings()` in der Klasse SimpleHelloWorld. Die Methode soll den String "Hello World!" zurückgeben.